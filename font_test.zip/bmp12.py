#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import struct

COLS = 50   # 横に50文字
ROWS = 138  # 縦に138行
GLYPH_W = 12
GLYPH_H = 12

def parse_bdf(path, target_w=12, target_h=12):
    glyphs = []
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        in_char = False
        in_bitmap = False
        current = {
            "encoding": None,
            "bbx": None,
            "bitmap": []
        }

        for line in f:
            line = line.strip()

            if line.startswith("STARTCHAR"):
                in_char = True
                in_bitmap = False
                current = {
                    "encoding": None,
                    "bbx": None,
                    "bitmap": []
                }

            elif line.startswith("ENDCHAR"):
                if (
                    current["bbx"] is not None and
                    current["bbx"][0] == target_w and
                    current["bbx"][1] == target_h and
                    len(current["bitmap"]) == target_h
                ):
                    glyphs.append(current)
                in_char = False
                in_bitmap = False

            elif in_char:
                if line.startswith("ENCODING"):
                    parts = line.split()
                    if len(parts) >= 2:
                        try:
                            current["encoding"] = int(parts[1])
                        except ValueError:
                            current["encoding"] = None

                elif line.startswith("BBX"):
                    parts = line.split()
                    if len(parts) >= 5:
                        w = int(parts[1])
                        h = int(parts[2])
                        xoff = int(parts[3])
                        yoff = int(parts[4])
                        current["bbx"] = (w, h, xoff, yoff)

                elif line == "BITMAP":
                    in_bitmap = True

                elif in_bitmap:
                    current["bitmap"].append(line)

    return glyphs


def glyph_bitmap_to_rows(glyph, width=GLYPH_W):
    """
    BDF BITMAP行（16進文字列）→ 12bit行配列に変換。
    東雲12ドットは16bit中の上位12bitを使用。
    xoffで左右補正。
    """
    w, h, xoff, yoff = glyph["bbx"]
    rows = []
    for hex_str in glyph["bitmap"]:
        value = int(hex_str, 16)
        # 上位12bitを取り出す（16bit → 12bit）
        value = (value >> 4) & 0xFFF

        # xoff による左右シフト補正
        if xoff > 0:
            value >>= xoff
        elif xoff < 0:
            value = (value << (-xoff)) & 0xFFF

        rows.append(value)
    return rows


def save_grid_bmp(filename, glyphs, cols=COLS, rows_count=ROWS,
                  glyph_w=GLYPH_W, glyph_h=GLYPH_H):
    """
    glyphs を横cols×縦rows_countのグリッドに敷き詰めてBMP出力。
    """
    total_slots = cols * rows_count
    total_glyphs = len(glyphs)
    print(f"Total glyphs: {total_glyphs}, slots: {total_slots}")

    # 各グリフを rows[] に変換
    glyph_rows_list = [glyph_bitmap_to_rows(g, glyph_w) for g in glyphs]

    # 足りないスロットは空白（0）で埋める
    while len(glyph_rows_list) < total_slots:
        glyph_rows_list.append([0] * glyph_h)

    total_width = glyph_w * cols
    total_height = glyph_h * rows_count

    # 1bit BMP の1行あたりバイト数（4バイト境界）
    row_bytes = ((total_width + 31) // 32) * 4
    pixel_data = bytearray()

    # BMPは下から上へ
    for out_y in range(total_height - 1, -1, -1):
        row_bits = 0
        bit_count = 0
        row_bytes_data = bytearray()

        cell_row = out_y // glyph_h
        inner_y = out_y % glyph_h

        for cell_col in range(cols):
            idx = cell_row * cols + cell_col
            rows12 = glyph_rows_list[idx]
            value = rows12[inner_y]

            for bit in range(glyph_w):
                mask = 1 << (glyph_w - 1 - bit)
                pixel = 0 if (value & mask) else 1  # 0=黒, 1=白

                row_bits = (row_bits << 1) | pixel
                bit_count += 1

                if bit_count == 8:
                    row_bytes_data.append(row_bits)
                    row_bits = 0
                    bit_count = 0

        if bit_count > 0:
            row_bits <<= (8 - bit_count)
            row_bytes_data.append(row_bits)

        while len(row_bytes_data) < row_bytes:
            row_bytes_data.append(0)

        pixel_data += row_bytes_data

    file_size = 54 + len(pixel_data)
    header = bytearray()

    # BITMAPFILEHEADER
    header += b"BM"
    header += struct.pack("<I", file_size)
    header += b"\x00\x00"
    header += b"\x00\x00"
    header += struct.pack("<I", 54)

    # BITMAPINFOHEADER
    header += struct.pack("<I", 40)                  # biSize
    header += struct.pack("<i", total_width)         # biWidth
    header += struct.pack("<i", total_height)        # biHeight
    header += struct.pack("<H", 1)                   # biPlanes
    header += struct.pack("<H", 1)                   # biBitCount (1bit)
    header += struct.pack("<I", 0)                   # biCompression (BI_RGB)
    header += struct.pack("<I", len(pixel_data))     # biSizeImage
    header += struct.pack("<I", 2835)                # biXPelsPerMeter
    header += struct.pack("<I", 2835)                # biYPelsPerMeter
    header += struct.pack("<I", 2)                   # biClrUsed
    header += struct.pack("<I", 0)                   # biClrImportant

    # パレット（黒・白）
    header += b"\x00\x00\x00\x00"  # 黒
    header += b"\xFF\xFF\xFF\x00"  # 白

    with open(filename, "wb") as f:
        f.write(header + pixel_data)


def main():
    if len(sys.argv) < 2:
        print("Usage: python bmp12_grid.py shnmk12.pdb")
        sys.exit(1)

    bdf_path = sys.argv[1]

    glyphs = parse_bdf(bdf_path, target_w=GLYPH_W, target_h=GLYPH_H)

    print(f"Parsed {len(glyphs)} glyphs from BDF/PDB")

    save_grid_bmp("font12_grid_50x138.bmp", glyphs,
                  cols=COLS, rows_count=ROWS,
                  glyph_w=GLYPH_W, glyph_h=GLYPH_H)

    print("Saved font12_grid_50x138.bmp")


if __name__ == "__main__":
    main()
