#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys

def parse_bdf(filepath):
    glyphs = {}
    with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
        in_char = False
        in_bitmap = False
        current = {}

        for line in f:
            line = line.strip()

            if line.startswith("STARTCHAR"):
                in_char = True
                in_bitmap = False
                current = {
                    "encoding": None,
                    "bbx": None,
                    "bitmap": []
                }

            elif line.startswith("ENDCHAR"):
                if current["encoding"] is not None:
                    glyphs[current["encoding"]] = current
                in_char = False
                in_bitmap = False

            elif in_char:
                if line.startswith("ENCODING"):
                    current["encoding"] = int(line.split()[1])

                elif line.startswith("BBX"):
                    parts = line.split()
                    w = int(parts[1])
                    h = int(parts[2])
                    xoff = int(parts[3])
                    yoff = int(parts[4])
                    current["bbx"] = (w, h, xoff, yoff)

                elif line == "BITMAP":
                    in_bitmap = True

                elif in_bitmap:
                    current["bitmap"].append(line)

    return glyphs


def show_bitmap(rows, width=12, xoff=0):
    for hex_str in rows:
        # 東雲12ドットは BITMAP が 16bit 幅なので 12bit に切り詰める
        value = int(hex_str, 16)
        value = (value >> 4) & 0xFFF

        line = " " * max(0, xoff)

        for bit in range(width):
            mask = 1 << (width - 1 - bit)
            line += "O" if (value & mask) else "_"

        print(line)


def main():
    if len(sys.argv) < 2:
        print("Usage: python v12100.py font.bdf")
        sys.exit(1)

    bdf_path = sys.argv[1]

    glyphs = parse_bdf(bdf_path)

    enc_list = sorted(glyphs.keys())

    print(f"Total glyphs: {len(enc_list)}\n")
    print("Showing first 100 glyphs:\n")

    for enc in enc_list[:100]:
        glyph = glyphs[enc]
        rows = glyph["bitmap"]
        w, h, xoff, yoff = glyph["bbx"]

        print(f"ENCODING {enc}")
        print(f"BBX: {glyph['bbx']}")
        show_bitmap(rows, width=w, xoff=xoff)
        print("")


if __name__ == "__main__":
    main()
