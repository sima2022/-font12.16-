#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import struct

COLS = 50   # 横に50文字
ROWS = 138  # 縦に138行
GLYPH_W = 16
GLYPH_H = 16

def parse_bdf(path, target_w=16, target_h=16):
    glyphs = []
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        in_char = False
        in_bitmap = False
        current = {
            "encoding": None,
            "bbx": None,
            "bitmap": []
        }

        for line in f:
            line = line.strip()

            if line.startswith("STARTCHAR"):
                in_char = True
                in_bitmap = False
                current = {
                    "encoding": None,
                    "bbx": None,
                    "bitmap": []
                }

            elif line.startswith("ENDCHAR"):
                if (
                    current["bbx"] is not None and
                    current["bbx"][0] == target_w and
                    current["bbx"][1] == target_h and
                    len(current["bitmap"]) == target_h
                ):
                    glyphs.append(current)
                in_char = False
                in_bitmap = False

            elif in_char:
                if line.startswith("ENCODING"):
                    parts = line.split()
                    if len(parts) >= 2:
                        try:
                            current["encoding"] = int(parts[1])
                        except ValueError:
                            current["encoding"] = None

                elif line.startswith("BBX"):
                    parts = line.split()
                    if len(parts) >= 5:
                        w = int(parts[1])
                        h = int(parts[2])
                        xoff = int(parts[3])
                        yoff = int(parts[4])
                        current["bbx"] = (w, h, xoff, yoff)

                elif line == "BITMAP":
                    in_bitmap = True

                elif in_bitmap:
                    current["bitmap"].append(line)

    return glyphs


def glyph_bitmap_to_rows(glyph, width=GLYPH_W):
    """
    BDF BITMAP行（16進文字列）→ 16bit行配列に変換。
    東雲16ドットは16bitをそのまま使用。
    xoffで左右補正。
    """
    w, h, xoff, yoff = glyph["bbx"]
    rows = []
    for hex_str in glyph["bitmap"]:
        value = int(hex_str, 16) & 0xFFFF  # 16bit

        # xoff による左右シフト補正
        if xoff > 0:
            value >>= xoff
        elif xoff < 0:
            value = (value << (-xoff)) & 0xFFFF

        rows.append(value)
    return rows


def save_grid_bmp(filename, glyphs, cols=COLS, rows_count=ROWS,
                  glyph_w=GLYPH_W, glyph_h=GLYPH_H):

    total_slots = cols * rows_count
    total_glyphs = len(glyphs)
    print(f"Total glyphs: {total_glyphs}, slots: {total_slots}")

    glyph_rows_list = [glyph_bitmap_to_rows(g, glyph_w) for g in glyphs]

    while len(glyph_rows_list) < total_slots:
        glyph_rows_list.append([0] * glyph_h)

    total_width = glyph_w * cols
    total_height = glyph_h * rows_count

    row_bytes = ((total_width + 31) // 32) * 4
    pixel_data = bytearray()

    for out_y in range(total_height - 1, -1, -1):
        row_bits = 0
        bit_count = 0
        row_bytes_data = bytearray()

        cell_row = out_y // glyph_h
        inner_y = out_y % glyph_h

        for cell_col in range(cols):
            idx = cell_row * cols + cell_col
            rows16 = glyph_rows_list[idx]
            value = rows16[inner_y]

            for bit in range(glyph_w):
                mask = 1 << (glyph_w - 1 - bit)
                pixel = 0 if (value & mask) else 1

                row_bits = (row_bits << 1) | pixel
                bit_count += 1

                if bit_count == 8:
                    row_bytes_data.append(row_bits)
                    row_bits = 0
                    bit_count = 0

        if bit_count > 0:
            row_bits <<= (8 - bit_count)
            row_bytes_data.append(row_bits)

        while len(row_bytes_data) < row_bytes:
            row_bytes_data.append(0)

        pixel_data += row_bytes_data

    file_size = 54 + len(pixel_data)
    header = bytearray()

    header += b"BM"
    header += struct.pack("<I", file_size)
    header += b"\x00\x00"
    header += b"\x00\x00"
    header += struct.pack("<I", 54)

    header += struct.pack("<I", 40)
    header += struct.pack("<i", total_width)
    header += struct.pack("<i", total_height)
    header += struct.pack("<H", 1)
    header += struct.pack("<H", 1)
    header += struct.pack("<I", 0)
    header += struct.pack("<I", len(pixel_data))
    header += struct.pack("<I", 2835)
    header += struct.pack("<I", 2835)
    header += struct.pack("<I", 2)
    header += struct.pack("<I", 0)

    header += b"\x00\x00\x00\x00"
    header += b"\xFF\xFF\xFF\x00"

    with open(filename, "wb") as f:
        f.write(header + pixel_data)


def main():
    if len(sys.argv) < 2:
        print("Usage: python bmp16_grid.py shnmk16.pdb")
        sys.exit(1)

    bdf_path = sys.argv[1]

    glyphs = parse_bdf(bdf_path, target_w=GLYPH_W, target_h=GLYPH_H)

    print(f"Parsed {len(glyphs)} glyphs from BDF/PDB")

    save_grid_bmp("font16_grid_50x138.bmp", glyphs,
                  cols=COLS, rows_count=ROWS,
                  glyph_w=GLYPH_W, glyph_h=GLYPH_H)

    print("Saved font16_grid_50x138.bmp")


if __name__ == "__main__":
    main()
